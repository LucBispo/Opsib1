﻿{
	"version": 1621960418,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"linha-sheet0.png",
		"ponto-sheet0.png",
		"ponto2-sheet0.png",
		"canvas.png",
		"fundo-sheet0.png",
		"sprite2-sheet0.png",
		"borda-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}